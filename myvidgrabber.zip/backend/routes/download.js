const express = require('express');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

const router = express.Router();
const DOWNLOAD_DIR = process.env.DOWNLOAD_DIR || './downloads';

if (!fs.existsSync(DOWNLOAD_DIR)) fs.mkdirSync(DOWNLOAD_DIR);

router.post('/', async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: 'URL required' });

  const output = path.join(DOWNLOAD_DIR, `video-%(title)s.%(ext)s`);

  const command = `yt-dlp -o "${output}" -f best "${url}"`;

  exec(command, (error, stdout, stderr) => {
    if (error) return res.status(500).json({ error: stderr });
    return res.json({ message: 'Download started', info: stdout });
  });
});

module.exports = router;